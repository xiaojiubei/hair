# 预览

- npm install
- npm run dev